/**
 * Copy a file from source to destination.
 *
 * @param source
 *        the source
 * @param destination
 *        the destination
 * @return True if succeeded , False if not
 */
// START
public static boolean copy(InputStream source , String destination) {
	boolean succeess = true;

	System.out.println("Copying ->" + source + "\n\tto ->" + destination);

	try {
		Files.copy(source, Paths.get(destination), StandardCopyOption.REPLACE_EXISTING);
	} catch (IOException ex) {
		logger.log(Level.WARNING, "", ex);
		succeess = false;
	}

	return succeess;

}
// END