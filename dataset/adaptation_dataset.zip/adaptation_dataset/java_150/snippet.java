String getTopPackage(){
    long ts = System.currentTimeMillis();
    UsageStatsManager mUsageStatsManager = (UsageStatsManager)getSystemService("usagestats");
    List<UsageStats> usageStats = mUsageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_BEST, ts-1000, ts);
    if (usageStats == null || usageStats.size() == 0) {
        return NONE_PKG;
    }
    Collections.sort(usageStats, mRecentComp);
    return usageStats.get(0).getPackageName();
}
