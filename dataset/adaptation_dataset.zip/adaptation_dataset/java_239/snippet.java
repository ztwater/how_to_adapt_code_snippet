public static URL getClassURL(Class klass) {
	// START
    String name = klass.getName();
    name = "/" + convertClassToPath(name);
    URL url = klass.getResource(name);
	// END
    return url;
}

public static String convertClassToPath(String className) {
    String path = className.replaceAll("\\.", "/") + ".class";
    return path;
}
