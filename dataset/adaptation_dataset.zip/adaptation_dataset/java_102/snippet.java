AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
builder.setMessage("Test for preventing dialog close");
builder.setPositiveButton("Test", 
		// START
        new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                //Do nothing here because we override this button later to change the close behaviour. 
                //However, we still need this because on older versions of Android unless we 
                //pass a handler the button doesn't get instantiated
            }
        }
		// END
		);
final AlertDialog dialog = builder.create();
dialog.show();
//Overriding the handler immediately after show is probably a better approach than OnShowListener as described below
dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener()
{            
	@Override
	public void onClick(View v)
	{
		Boolean wantToCloseDialog = false;
		//Do stuff, possibly set wantToCloseDialog to true then...
		if(wantToCloseDialog)
			dialog.dismiss();
		//else dialog stays open. Make sure you have an obvious way to close the dialog especially if you set cancellable to false.
	}
});

