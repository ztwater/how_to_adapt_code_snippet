// START
String macAddress = android.provider.Settings.Secure.getString(context.getContentResolver(), "bluetooth_address");
// END