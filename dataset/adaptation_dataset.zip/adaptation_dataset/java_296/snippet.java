// START
private void fixMouse(Stage primaryStage)
{
	Platform.runLater(()->{
		//Show mouse cursor
		Robot robot = com.sun.glass.ui.Application.GetApplication().createRobot();

		robot.mouseMove(790,470);
		robot.destroy();

		//Show fullscreen dialog
		final Stage dialog = new Stage();
		dialog.initModality(Modality.APPLICATION_MODAL);
		dialog.initOwner(primaryStage);

		StackPane dialogLayout = new StackPane();
		dialog.setFullScreen(true);
		dialog.setResizable(false);
		dialog.setFullScreenExitKeyCombination(KeyCombination.NO_MATCH);

		Scene dialogScene = new Scene(dialogLayout, 0, 0);
		dialogScene.setCursor(Cursor.NONE);
		dialogScene.setFill(Color.BLACK);
		dialogLayout.setBackground(Background.EMPTY);

		dialog.setScene(dialogScene);
		dialog.show();

		// Auto close the dialog
		Platform.runLater(()->{
					dialog.close();
					primaryStage.setFullScreen(true);
				});
		});
}
// END