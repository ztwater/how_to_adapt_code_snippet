java.util.logging.Logger.getLogger("org.hibernate").setLevel(Level.OFF);
