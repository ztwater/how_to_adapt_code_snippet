// START
Intent intent = getIntent();
finish();
startActivity(intent);
// END