import javafx.application.Application;

public class Start {

    public static void main(String[] args) {

        //must be set before launching the Main class
		// START
        System.setProperty("quantum.multithreaded", "false");
		// END
        Application.launch(Main.class, args);
    }
}
