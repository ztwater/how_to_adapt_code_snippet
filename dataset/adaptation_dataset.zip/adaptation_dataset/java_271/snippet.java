Enumeration<URL> en = getClass().getClassLoader().getResources(
		"META-INF");
List<String> profiles = new ArrayList<>();
while (en.hasMoreElements()) {
	URL url = en.nextElement();
	// START
	JarURLConnection urlcon = (JarURLConnection) (url.openConnection());
	try (JarFile jar = urlcon.getJarFile();) {
		Enumeration<JarEntry> entries = jar.entries();
		while (entries.hasMoreElements()) {
			String entry = entries.nextElement().getName();
			System.out.println(entry);
		}
	}
	// END 
}
