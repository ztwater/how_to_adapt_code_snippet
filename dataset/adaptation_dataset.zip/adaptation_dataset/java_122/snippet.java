JTable auditTable = new JTable(){
	
	//Implement table cell tool tips.   
	// START	
	public String getToolTipText(MouseEvent e) {
		String tip = null;
		java.awt.Point p = e.getPoint();
		int rowIndex = rowAtPoint(p);
		int colIndex = columnAtPoint(p);

		try {
			tip = getValueAt(rowIndex, colIndex).toString();
		} catch (RuntimeException e1) {
			//catch null pointer exception if mouse is over an empty line
		}

		return tip;
	}
	// END
};
