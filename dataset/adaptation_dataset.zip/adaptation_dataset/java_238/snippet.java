public abstract class Foo<E> {
	public E instance;
	public Foo() throws Exception {
	// START
	instance = ((Class)((ParameterizedType)this.getClass().
		getGenericSuperclass()).getActualTypeArguments()[0]).newInstance();
	// END
	...
	}
}
