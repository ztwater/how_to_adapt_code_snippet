Bitmap bwBitmap = Bitmap.createBitmap( bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.RGB_565 );
// START
float[] hsv = new float[ 3 ];
for( int col = 0; col < bitmap.getWidth(); col++ ) {
	for( int row = 0; row < bitmap.getHeight(); row++ ) {
		Color.colorToHSV( bitmap.getPixel( col, row ), hsv );
		if( hsv[ 2 ] > 0.5f ) {
			bwBitmap.setPixel( col, row, 0xffffffff );
		} else {
			bwBitmap.setPixel( col, row, 0xff000000 );
		}
	}
}
// END
return bwBitmap;

