public static double getDurationOfWavInSeconds(File file)
{   
    AudioInputStream stream = null;

    try 
    {
        stream = AudioSystem.getAudioInputStream(file);

        AudioFormat format = stream.getFormat();

        return file.length() / format.getSampleRate() / (format.getSampleSizeInBits() / 8.0) / format.getChannels();
    }
    catch (Exception e) 
    {
        // log an error
        return -1;
    }
    finally
    {
        try { stream.close(); } catch (Exception ex) { }
    }
}
