    public void createPDFFromImage(String pdfFile, 
        List<String> imgList,int x, int y, float scale) throws IOException, COSVisitorException {
    // the document
    PDDocument doc = null;
    try {
        doc = new PDDocument();
        Iterator iter = imgList.iterator();
        int imgIndex=0;
        while(iter.hasNext()) {
            PDPage page = new PDPage();
            doc.addPage(page);

            BufferedImage tmp_image = ImageIO.read(new File(iter.next().toString()));
            BufferedImage image = new BufferedImage(tmp_image.getWidth(), tmp_image.getHeight(), BufferedImage.TYPE_4BYTE_ABGR);        
            image.createGraphics().drawRenderedImage(tmp_image, null);

            PDXObjectImage ximage = new PDPixelMap(doc, image);

            imgIndex++;


            PDPageContentStream contentStream = new PDPageContentStream(
                    doc, page,true,true);
			// START
            contentStream.drawXObject(ximage, x, y, ximage.getWidth()*scale, ximage.getHeight()*scale);
			// END
            contentStream.close();
        }
        doc.save(pdfFile);
    } finally {
        if (doc != null) {
            doc.close();
        }
    }
}
