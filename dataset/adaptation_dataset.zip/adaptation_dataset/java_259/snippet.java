// START
int count = line.length() - line.replace(".", "").length();
// END