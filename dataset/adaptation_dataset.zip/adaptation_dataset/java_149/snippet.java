// START
String path = this.getClass().getClassLoader().getResource(<resourceFileName>).toExternalForm()
// END
