            git.add().setUpdate(true).addFilepattern(".").call();
            git.commit().setMessage("delete files").call();
            RefSpec spec = new RefSpec("refs/heads/master:refs/remotes/branch1");
            git.push().setRemote("origin").setRefSpecs(spec).call();
