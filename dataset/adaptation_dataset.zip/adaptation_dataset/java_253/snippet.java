// START
((BitmapDrawable)ascender.getDrawable()).setTileModeY(TileMode.CLAMP);
// END