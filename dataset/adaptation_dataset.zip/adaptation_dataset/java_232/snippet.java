// START  
Stream.of(1, 3, 4, 6, 7, 5, 6)
			.collect(Collectors.groupingBy(
                    Function.identity(), Collectors.counting()))
            .entrySet().stream().anyMatch(e -> e.getValue() > 1)
// END