int occurrences = Collections.frequency(animals, "bat");
