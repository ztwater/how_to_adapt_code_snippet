// START
Location me   = new Location("");
Location dest = new Location("");

me.setLatitude(myLat);
me.setLongitude(myLong);

dest.setLatitude(destLat);
dest.setLongitude(destLong);

float dist = me.distanceTo(dest);
// END