// START
@Override
public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
    RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widgetlayout);
    Intent configIntent = new Intent(context, Activity.class);

    PendingIntent configPendingIntent = PendingIntent.getActivity(context, 0, configIntent, 0);

    remoteViews.setOnClickPendingIntent(R.id.widget, configPendingIntent);
    appWidgetManager.updateAppWidget(appWidgetIds, remoteViews);
}
// END
