@Override
public void onCreate() {
    super.onCreate();
	// START
    startForeground(1,new Notification());
	// END
}
