public class MainActivity extends AppCompatActivity{
	// START
	boolean automaticChanged = false;
	TextWatcher textWatcher = new TextWatcher() {
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			if (!automaticChanged) {
				// do stuff
			} else {
				automaticChanged = false;
			}
		}
	};
	// END
}
