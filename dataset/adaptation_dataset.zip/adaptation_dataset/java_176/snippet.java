JarURLConnection con = ...;
// START
con.setUseCaches(false);
// END
JarFile jarFile = jarConn.getJarFile();
