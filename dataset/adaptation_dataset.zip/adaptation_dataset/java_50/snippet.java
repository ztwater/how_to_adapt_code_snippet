theta = 2 * PI * U;
phi = PI * V;

_x = Math.cos(theta) * Math.sin(phi) * radius;
_y = Math.sin(theta) * Math.sin(phi) * radius;
_z = -Math.cos(phi) * radius;
