ClassLoader.getResourceAsStream ("some/pkg/resource.properties");
