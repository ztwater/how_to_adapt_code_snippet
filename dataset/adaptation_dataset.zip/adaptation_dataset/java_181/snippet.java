val dialog = builder.setView(password).setMessage("message")
            .setPositiveButton("confirm", { doSomethingFunction() })
            .setNegativeButton("cancel", { dialog, i -> }).show()

password.setOnEditorActionListener({
    if(id == EditorInfo.IME_ACTION_GO) { v, id, event ->
		// START
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()        
		// END
	}
    false
}) 
