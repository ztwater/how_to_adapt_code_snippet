// START
@Before
public void setup() {
    HttpServletRequest mockRequest = new MockHttpServletRequest();
    ServletRequestAttributes servletRequestAttributes = new ServletRequestAttributes(mockRequest);
    RequestContextHolder.setRequestAttributes(servletRequestAttributes);
}
// END
@After
public void teardown() {
    RequestContextHolder.resetRequestAttributes();
}
