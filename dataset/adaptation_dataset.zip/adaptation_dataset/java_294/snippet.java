// START
public static int compareVersion(String version1, String version2)
{
	String[] arr1 = version1.split("\\.");
	String[] arr2 = version2.split("\\.");

	if (arr1.length < arr2.length)
		return -1;
	if (arr1.length > arr2.length)
		return 1;

	// same number of version "." dots
	for (int i = 0; i < arr1.length; i++)
	{
		if(Integer.parseInt(arr1[i]) < Integer.parseInt(arr2[i]))
			return -1;
		if(Integer.parseInt(arr1[i]) > Integer.parseInt(arr2[i]))
			return 1;
	}
	// went through all version numbers and they are all the same
	return 0;
}
// END
