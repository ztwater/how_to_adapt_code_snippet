// START    
@SuppressWarnings({"rawtypes", "unchecked"})
static void deepMerge(
        Map original,
        Map newMap) {

    for (Entry e : (Set<Entry>) newMap.entrySet()) {
        Object
            key = e.getKey(),
            value = e.getValue();

        // unfortunately, if null-values are allowed,
        // we suffer the performance hit of double-lookup
        if (original.containsKey(key)) {
            Object originalValue = original.get(key);

            if (Objects.equal(originalValue, value))
                return;

            if (originalValue instanceof Collection) {
                // this could be relaxed to simply to simply add instead of addAll
                // IF it's not a collection (still addAll if it is),
                // this would be a useful approach, but uncomfortably inconsistent, algebraically
                Preconditions.checkArgument(value instanceof Collection,
                        "a non-collection collided with a collection: %s%n\t%s",
                        value, originalValue);

                ((Collection) originalValue).addAll((Collection) value);

                return;
            }

            if (originalValue instanceof Map) {
                Preconditions.checkArgument(value instanceof Map,
                        "a non-map collided with a map: %s%n\t%s",
                        value, originalValue);

                deepMerge((Map) originalValue, (Map) value);

                return;
            }

            throw new IllegalArgumentException(String.format(
                    "collision detected: %s%n%\torig:%s",
                    value, originalValue));

        } else
            original.put(key, value);
    }
}
// END