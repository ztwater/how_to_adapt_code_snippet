 private class MyLongClickListener implements View.OnLongClickListener {
  EditText editText;
  TextView textView ;
 @Override
        public boolean onLongClick(View view) {
            editText =(EditText) view.findViewById(R.id.editText);
            textView =(TextView) view.findViewById(R.id.textView);
            editText.bringToFront();
            textView.setVisibility(View.INVISIBLE);
            editText.setVisibility(View.VISIBLE);
            if (editText.requestFocus()) {
                InputMethodManager imm = (InputMethodManager)
                        getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT);

            }
            textView.setText(editText.getText().toString());
            editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if(actionId== EditorInfo.IME_ACTION_DONE){
                        editText.setVisibility(View.INVISIBLE);
                        textView.bringToFront();
                        textView.setVisibility(View.VISIBLE);
                        textView.setText(editText.getText().toString());
                    }
                    return false;
                }
            });

            return true;
        }
}
