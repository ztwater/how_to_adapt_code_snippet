itemList = (ListPreference)findPreference("itemList");
itemList2 = (ListPreference)findPreference("itemList2");
itemList.setOnPreferenceChangeListener(new
Preference.OnPreferenceChangeListener() {
  public boolean onPreferenceChange(Preference preference, Object newValue) {
    final String val = newValue.toString();
    int index = itemList.findIndexOfValue(val);
    if(index==3)
      itemList2.setEnabled(true);
    else
      itemList2.setEnabled(false);
    return true;
  }
});
