final private JPanel nodeRenderer = new JPanel();
final private JLabel label = new JLabel();
final private JCheckBox check = new JCheckBox();

     ...

// in constructor:
final Insets inset0=new Insets(0,0,0,0);        
this.check.setMargin(inset0);
this.nodeRenderer.setLayout(new BorderLayout()); 
this.nodeRenderer.add(this.check, BorderLayout.WEST);
this.nodeRenderer.add(this.label, BorderLayout.CENTER);
