String str = "Location \"Welcome  to india\" Bangalore " +
             "Channai \"IT city\"  Mysore";

List<String> list = new ArrayList<String>();
// START
Matcher m = Pattern.compile("([^\"]\\S*|\".+?\")\\s*").matcher(str);
while (m.find())
    list.add(m.group(1)); // Add .replace("\"", "") to remove surrounding quotes.
// END

System.out.println(list);
