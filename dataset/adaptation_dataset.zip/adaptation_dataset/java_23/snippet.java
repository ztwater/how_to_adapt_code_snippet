text.matches("\\A\\p{ASCII}*\\z")
