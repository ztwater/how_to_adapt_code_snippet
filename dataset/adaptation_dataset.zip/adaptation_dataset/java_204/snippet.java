GeoPoint location = new GeoPoint(
            (int) (mLocation.getLatitude()) * 1E6), 
            (int) (mLocation.getLongitude()) * 1E6)
                     );
