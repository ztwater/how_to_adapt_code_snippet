static {
    AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
}
