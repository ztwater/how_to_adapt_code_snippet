// START
myNumberPicker.clearFocus();
// END