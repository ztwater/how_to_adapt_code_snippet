// START
for (String key: bundle.keySet())
{
  Log.d ("myApplication", key + " is a key in the bundle");
}
// END 
