    // Fixing Later Map loading Delay
    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                MapView mv = new MapView(getApplicationContext());
                mv.onCreate(null);
                mv.onPause();
                mv.onDestroy();
            }catch (Exception ignored){

            }
        }
    }).start();
