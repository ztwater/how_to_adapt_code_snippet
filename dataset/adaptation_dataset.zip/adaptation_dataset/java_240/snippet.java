BufferedWriter writer = null;
try
{
	// START
    writer = new BufferedWriter( new FileWriter( yourfilename));
    writer.write( yourstring);
	// END

}
catch ( IOException e)
{
}
finally
{
    try
    {
        if ( writer != null)
        writer.close( );
    }
    catch ( IOException e)
    {
    }
}
