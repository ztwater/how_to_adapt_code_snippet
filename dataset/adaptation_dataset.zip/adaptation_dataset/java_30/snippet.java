Toolkit toolkit = Toolkit.getDefaultToolkit();
Image image = toolkit.getImage("icons/handwriting.gif");
Cursor c = toolkit.createCustomCursor(image , new Point(mainPane.getX(), 
           mainPane.getY()), "img");
mainPane.setCursor (c);
