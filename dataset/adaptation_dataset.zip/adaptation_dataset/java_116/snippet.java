@Override
  public void onUpdate(Context context, AppWidgetManager appWidgetManager, int appWidgetIds[]){
      super.onUpdate(context, appWidgetManager, appWidgetIds);
      final int N = appWidgetIds.length;
      for (int i=0; i<N; i++) {
          int appWidgetId = appWidgetIds[i];
          Bundle options = appWidgetManager.getAppWidgetOptions(appWidgetId);
          if(options!=null){
              int nwidth = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH);
              int nheight = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT);
              onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, options);
          }
      }
  }
