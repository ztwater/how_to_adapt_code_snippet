if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
    ttsGreater21(text);
} else {
    ttsUnder20(text);
}
@SuppressWarnings("deprecation")
private void ttsUnder20(String text) {
    HashMap<String, String> map = new HashMap<>();
    map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "MessageId");
    tts.speak(text, TextToSpeech.QUEUE_FLUSH, map);
}

@TargetApi(Build.VERSION_CODES.LOLLIPOP)
private void ttsGreater21(String text) {
    String utteranceId=this.hashCode() + "";
    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId);
}
