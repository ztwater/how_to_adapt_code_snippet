// START
public String read(InputStream input) throws IOException {
    ImageInputStream stream = ImageIO.createImageInputStream(input);

    Iterator iter = ImageIO.getImageReaders(stream);
    if (!iter.hasNext()) {
        return null;
    }
    ImageReader reader = (ImageReader) iter.next();
    ImageReadParam param = reader.getDefaultReadParam();
    reader.setInput(stream, true, true);
    BufferedImage bi;
    try {
        bi = reader.read(0, param);
        return reader.getFormatName();
    } finally {
        reader.dispose();
        stream.close();
    }
}
// END