// START
Editable text = edit.getText();
if (text.length() > 0) {
	text.replace(0, 1, text.subSequence(0, 1), 0, 1);
	edit.selectAll();
}
// END