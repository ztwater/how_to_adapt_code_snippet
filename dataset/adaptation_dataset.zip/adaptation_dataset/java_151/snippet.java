try {
    final Field fEditor = TextView.class.getDeclaredField("mEditor");
    fEditor.setAccessible(true);
    final Object editor = fEditor.get(editText);
	
	// START
    final Field fSelectHandleLeft = editor.getClass().getDeclaredField("mSelectHandleLeft");
    final Field fSelectHandleRight =
        editor.getClass().getDeclaredField("mSelectHandleRight");
    final Field fSelectHandleCenter =
        editor.getClass().getDeclaredField("mSelectHandleCenter");

    fSelectHandleLeft.setAccessible(true);
    fSelectHandleRight.setAccessible(true);
    fSelectHandleCenter.setAccessible(true);
	// END
    final Resources res = context.getResources();

    fSelectHandleLeft.set(editor, res.getDrawable(R.drawable.text_select_handle_left));
    fSelectHandleRight.set(editor, res.getDrawable(R.drawable.text_select_handle_right));
    fSelectHandleCenter.set(editor, res.getDrawable(R.drawable.text_select_handle_middle));
} catch (final Exception ignored) {
}
