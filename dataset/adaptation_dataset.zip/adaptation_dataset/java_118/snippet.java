// START 
stream::iterator
// END
