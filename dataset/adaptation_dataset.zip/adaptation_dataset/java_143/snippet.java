JDialog dialog = new JDialog((Dialog)null);
