    public ViewHolder(View itemView) {
        super(itemView);

        // Make this view clickable
		// START
        itemView.setClickable(true);
		// END
        // ...
    } 
