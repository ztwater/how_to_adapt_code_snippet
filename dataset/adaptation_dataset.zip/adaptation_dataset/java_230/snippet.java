import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

class EditorCombo extends JComboBox<String> {
	public EditorCombo() {
		super();
		setEditable(true);
		for (int i = 0; i < 10; i++) {
			addItem("Sample" + i);
		}
	}
	
	// START
	@Override 
	public void updateUI() {
		//super.updateUI();
		setUI(new javax.swing.plaf.synth.SynthComboBoxUI() {
			@Override
			protected JButton createArrowButton() {
				JButton button = new JButton() {
					@Override
					public int getWidth() {
						return 0;
					}
				};
				button.setBorder(BorderFactory.createEmptyBorder());
				button.setVisible(false);
				return button;
			}
			@Override
			public void configureArrowButton() {
			}
		});
		UIDefaults d = new UIDefaults();

		Painter<JComponent> emptyPainter = new Painter<JComponent>() {
			@Override public void paint(Graphics2D g, JComponent c, int w, int h) {
				/* Empty painter */
			}
		};
		d.put("TextField.borderPainter", emptyPainter);
		d.put("TextField[Enabled].borderPainter", emptyPainter);
		d.put("TextField[Focused].borderPainter", emptyPainter);
		d.put("ComboBox:\"ComboBox.textField\"[Enabled].backgroundPainter", emptyPainter);
		d.put("ComboBox:\"ComboBox.textField\"[Selected].backgroundPainter", emptyPainter);
		d.put("ComboBox[Editable+Focused].backgroundPainter", emptyPainter);
		putClientProperty("Nimbus.Overrides", d);
		JComponent c = (JComponent) getEditor().getEditorComponent();
		c.putClientProperty("Nimbus.Overrides", d);
		c.setBorder(BorderFactory.createLineBorder(Color.BLACK));
	}
	// END
}
