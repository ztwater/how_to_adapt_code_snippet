// START
String dirname = "profiles/";
Enumeration<URL> en = Detector.class.getClassLoader().getResources(
		dirname);
List<String> profiles = new ArrayList<>();
if (en.hasMoreElements()) {
	URL url = en.nextElement();
	JarURLConnection urlcon = (JarURLConnection) url.openConnection();
	try (JarFile jar = urlcon.getJarFile();) {
		Enumeration<JarEntry> entries = jar.entries();
		while (entries.hasMoreElements()) {
			String entry = entries.nextElement().getName();
			if (entry.startsWith(dirname)) {
				try (InputStream in = Detector.class.getClassLoader()
						.getResourceAsStream(entry);) {
					profiles.add(IOUtils.toString(in));
				}
			}
		}
	}
}

DetectorFactory.loadProfile(profiles);
// END
Detector detector = DetectorFactory.create();
detector.append(text);
String langDetected = detector.detect();
System.out.println(langDetected);
