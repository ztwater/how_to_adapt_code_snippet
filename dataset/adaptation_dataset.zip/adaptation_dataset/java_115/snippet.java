pane.getViewport().setBackground(Color.WHITE);
