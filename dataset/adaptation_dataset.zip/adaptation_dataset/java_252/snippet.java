// START
Integer x = Integer.valueOf(str);
// END
// or
int y = Integer.parseInt(str);
