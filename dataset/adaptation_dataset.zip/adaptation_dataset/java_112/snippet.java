// START
boolean isContentView(View child) {
    if(child == null){
        return false;
    }
    return ((LayoutParams) child.getLayoutParams()).gravity == Gravity.NO_GRAVITY;
}
// END