// START
Patterns.WEB_URL.matcher(potentialUrl).matches()
// END