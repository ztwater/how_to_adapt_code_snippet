// START
public static final Parcelable.Creator<Item> CREATOR 
        = new Parcelable.Creator<Item>() {
    public Item createFromParcel(Parcel in) {
        return new Item(in);
    }

    public Item[] newArray(int size) {
        return new Item[size];
    }
};
// END