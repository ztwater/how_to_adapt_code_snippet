// START_1
d = Math.round(d*100)/100.0d;
// END_1