    public class ObservableMerge {
        static ObservableList<String> a = FXCollections.observableArrayList();
        static ObservableList<String> b = FXCollections.observableArrayList();

        static ObservableList<String> aandb = FXCollections.observableArrayList();


        static ObservableList<String> merge(ObservableList<String> into, ObservableList<String>... lists) {
            final ObservableList<String> list = into;
            for (ObservableList<String> l : lists) {
                list.addAll(l);
                l.addListener((javafx.collections.ListChangeListener.Change<? extends String> c) -> {
                    while (c.next()) {
                        if (c.wasAdded()) {
                            list.addAll(c.getAddedSubList());
                        }
                        if (c.wasRemoved()) {
                            list.removeAll(c.getRemoved());
                        }
                    }
                });
            }

            return list;
        }
        public static void main(String...args) {
            merge(aandb, a, b);

            System.out.println(""+aandb);
            a.add("Hello");
            b.add("Peter");
            System.out.println(""+aandb);

        }
    }
