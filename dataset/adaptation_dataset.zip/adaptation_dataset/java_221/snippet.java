private boolean stringMatchesChars(final String str, final List<Character> characters) {
    return (str.chars()
            .filter(ch -> characters.contains((char)ch))
            .count() == 1);
}
