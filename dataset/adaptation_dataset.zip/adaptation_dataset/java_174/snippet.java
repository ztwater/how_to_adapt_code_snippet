/** 
@param context : it is the reference where this method get called
@param docPath : absolute path of file for which broadcast will be send to refresh media database
**/
public static void refreshSystemMediaScanDataBase(Context context, String docPath){
   Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
   Uri contentUri = Uri.fromFile(new File(docPath));
   mediaScanIntent.setData(contentUri);
   context.sendBroadcast(mediaScanIntent);
}
