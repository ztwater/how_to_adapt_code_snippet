localAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
localAudioManager.setMode(0);
localAudioManager.setBluetoothScoOn(true);
// START
localAudioManager.startBluetoothSco();
// END
localAudioManager.setMode(AudioManager.MODE_IN_CALL);
