// START
public String getWFDMacAddress(){
    try {
        List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
        for (NetworkInterface ntwInterface : interfaces) {

            if (ntwInterface.getName().equalsIgnoreCase("p2p0")) {
                byte[] byteMac = ntwInterface.getHardwareAddress();
                if (byteMac==null){
                    return null;
                }
                StringBuilder strBuilder = new StringBuilder();
                for (int i=0; i<byteMac.length; i++) {
                    strBuilder.append(String.format("%02X:", byteMac[i]));
                }

                if (strBuilder.length()>0){
                    strBuilder.deleteCharAt(strBuilder.length()-1);
                }

                return strBuilder.toString();
            }

        }
    } catch (Exception e) {
        Log.d(TAG, e.getMessage());
    }
    return null;
}
// END