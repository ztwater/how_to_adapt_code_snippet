@Nullable String testLabSetting =
  Settings.System.getString(context.getContentResolver(), "firebase.test.lab");
if ("true".equals(testLabSetting)) {
  // Do something when running in Test Lab
}
