// START_1
String delim = "";
for (Item i : list) {
    sb.append(delim).append(i);
    delim = ",";
}
// END_1