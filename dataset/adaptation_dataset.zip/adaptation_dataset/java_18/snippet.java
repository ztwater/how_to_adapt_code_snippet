@Override
public void onAttachedToWindow() {
    super.onAttachedToWindow();
    // START_1
    Window window = getWindow();
    window.setFormat(PixelFormat.RGBA_8888);
    // END_1
}
