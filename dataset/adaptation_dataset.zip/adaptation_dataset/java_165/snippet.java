webView.setWebViewClient(new WebViewClient(){
	@TargetApi(Build.VERSION_CODES.JELLY_BEAN)
	// START
	@Override
	public void onPageFinished(WebView view, String url) {
		if (searchText != null && !searchText.equals("")) {
			webView.findAllAsync(searchText);
		}
	}
	// END
});
