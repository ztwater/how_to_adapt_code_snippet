// START  
hadoopConfig.set("fs.hdfs.impl", 
	org.apache.hadoop.hdfs.DistributedFileSystem.class.getName()
);
// END
hadoopConfig.set("fs.file.impl",
	org.apache.hadoop.fs.LocalFileSystem.class.getName()
);
